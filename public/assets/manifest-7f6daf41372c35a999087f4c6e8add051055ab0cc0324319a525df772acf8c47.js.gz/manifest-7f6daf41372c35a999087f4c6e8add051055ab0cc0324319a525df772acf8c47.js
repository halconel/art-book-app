// Manifest file for webpack assets

;
